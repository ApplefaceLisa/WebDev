package com.irahul.tbtf.service.exception;

public enum ErrorCode {
	INVALID_FIELD,
	MISSING_DATA, 
	NOT_FOUND
}
