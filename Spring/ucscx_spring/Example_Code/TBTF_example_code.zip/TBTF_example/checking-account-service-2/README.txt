Example Java Spring Application

Copyright (C) 2017 Rahul Agarwal
http://www.irahul.com
This work is licensed under the Creative Commons Attribution-NonCommercial 4.0 International License. To view a copy of this license, visit http://creativecommons.org/licenses/by-nc/4.0/deed.en_US.

Notes:
*Each microservice is defined in its own Maven project
*Using long for ids. Consider strongly typing them
*Partially implemented services and tests
*Using Crud repositories to access MySQL DB
*Using RestTemplate to access user microservice

