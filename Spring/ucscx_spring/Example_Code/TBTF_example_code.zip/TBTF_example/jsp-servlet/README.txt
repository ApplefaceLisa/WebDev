Compiled classes location:
C:\Users\rahul\workspace\.metadata\.plugins\org.eclipse.wst.server.core\tmp0\work\Catalina\localhost\jsp-servlet\org\apache\jsp

Run Server either in eclipse or mvn tomcat7:run

Servlet:
http://localhost:8080/hello

JSP:
http://localhost:8080/hello.jsp?name=foo
http://localhost:8080/mix.jsp

See logs for filter output

In eclipse make sure to add the project name context: jsp-servlet
eg: http://localhost:8080/jsp-servlet/hello