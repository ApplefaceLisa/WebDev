package com.irahul.tbtf.service;

import com.irahul.tbtf.entity.CheckingAccount;
import com.irahul.tbtf.entity.impl.CheckingAccountImpl;

public interface CheckingAccountService {

	CheckingAccount getAccount(long accountId);
	
	Iterable<CheckingAccountImpl> getAccountsForUser(long userId);
	
	void deposit(long accountId, int totalDeposit, int availableNow);
	
	void withdraw(long accountId, int amount);

	CheckingAccount addAccount(CheckingAccount accountToCreate);
}
