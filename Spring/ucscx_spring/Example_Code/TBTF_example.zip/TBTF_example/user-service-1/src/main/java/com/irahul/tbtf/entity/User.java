package com.irahul.tbtf.entity;

public interface User {
	long getId();	
	String getFirstName();
	String getLastName();
	String getPin();
}
