Example Java Spring Application

Copyright (C) 2017 Rahul Agarwal
http://www.irahul.com
This work is licensed under the Creative Commons Attribution-NonCommercial 4.0 International License. To view a copy of this license, visit http://creativecommons.org/licenses/by-nc/4.0/deed.en_US.

Notes:
*Make sure your server is running with user-service3