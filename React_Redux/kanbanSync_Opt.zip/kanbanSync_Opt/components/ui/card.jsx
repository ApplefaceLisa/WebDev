import React from 'react';

import TaskList from './task-list.jsx';

export default class Card extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            showDetails: false
        }
    }
    
    handleEditCard() {
        this.props.editCard(this.props.card);
    }
    
    handleRemoveCard() {
        this.props.removeCard(this.props.card.get('id'));
    }
    
    handleAddTask(taskName) {
        this.props.addTask(this.props.card.get('id'), taskName);
    }
    
    handleRemoveTask(taskId) {
        this.props.removeTask(this.props.card.get('id'), taskId);
    }
    
    handleToggleTask(taskId) {
        this.props.toggleTask(this.props.card.get('id'), taskId);
    }

    handleClick() {
        this.setState({
            showDetails: !this.state.showDetails
        });
    }
    
    render() {
        let className = 'hidden';
        if (this.state.showDetails) {
            className = '';
        }
        return (
            <div className="card">
                <div 
                    className = { this.state.showDetails ? "card_title_is_open" : "card_title" }
                    onClick = { this.handleClick.bind(this) }
                >{this.props.card.get('title')}
                </div>
                <div className="card_edit">
                    <span 
                      className="glyphicon glyphicon-edit" aria-hidden="true"
                      onClick = { this.handleEditCard.bind(this) } >
                    </span>
                    <span 
                      className="glyphicon glyphicon-trash" aria-hidden="true"
                      onClick = { this.handleRemoveCard.bind(this) } >
                    </span>
                </div>
                <div 
                    className= {className}
                >
                    <div>{this.props.card.get('description')}</div>
                    <TaskList
                        tasks = {this.props.card.get('tasks')}

                        addTask = {this.handleAddTask.bind(this)}
                        toggleTask = {this.handleToggleTask.bind(this)}
                        removeTask = {this.handleRemoveTask.bind(this)}                    
                    />
                </div>
            </div>
        )
    }
}